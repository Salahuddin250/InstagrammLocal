import { LoginForm } from '@/features'
import cls from "./LoginPage.module.scss"

const LoginPage = () => {
  return (
     <LoginForm/>
  )
}

export default LoginPage
