import { RegisterForm } from "@/features"

const RegisterPage = () => {
  return (
    <RegisterForm/>
  )
}

export default RegisterPage
