import cls from "./Modal.module.scss"

interface AuthModalProps {
  isOpen: boolean
  isClose: boolean
}

export const AuthModal = () => {
  return (
     <div>Modal</div>
  )
}
