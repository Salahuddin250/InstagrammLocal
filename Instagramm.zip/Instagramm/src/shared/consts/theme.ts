export enum Theme {
  DARK = "app_dark",
  LIGHT = "app_light"
}
