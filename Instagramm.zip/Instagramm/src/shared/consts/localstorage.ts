export const LOCAL_STORAGE_THEME = "theme"
